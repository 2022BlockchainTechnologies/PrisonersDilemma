var PrisonersDilemma = artifacts.require("PrisonersDilemma");

module.exports = function(_deployer) {
  _deployer.deploy(PrisonersDilemma);
};
